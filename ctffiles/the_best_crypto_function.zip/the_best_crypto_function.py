def crypto_func(flag: str) -> str:
  line = ''
  for ch in flag:
      line += decimal_to_bin(ord(ch))

  res = ''
  for i in range(0, len(line), 3):
      res += str(bin_to_decimal(line[i:i+3]))

  return res


def decimal_to_bin(number: int) -> str:
  res = ''
  while number > 0:
      res += str(number % 2)
      number //= 2
  return res[::-1].rjust(9, '0')


def bin_to_decimal(bin: str) -> int:
  bin = bin[::-1]
  res = 0
  for i in range(len(bin)):
      res += int(bin[i]) * 2**(i)
      number //= 2
  return res[::-1].rjust(9, '0')


def bin_to_decimal(bin: str) -> int:
  bin = bin[::-1]
  res = 0
  for i in range(len(bin)):
      res += int(bin[i]) * 2**(i)


  return int(res)




res = crypto_func(flag)
print(res)
#output: 155147156150061154154163173141156156060171061156147137156165155142063162137163171163164063155163175
