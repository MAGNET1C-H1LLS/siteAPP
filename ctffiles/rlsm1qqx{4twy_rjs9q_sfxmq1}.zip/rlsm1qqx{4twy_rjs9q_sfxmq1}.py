def reveal_message(hidden):
   message = ""
   for i in range(len(hidden)):
       if hidden[i].isalpha():
           message += chr(ord('a') + (ord(hidden[i]) - ord('a') - 5) % 26)
       else:
           message += hidden[i]
   return message
